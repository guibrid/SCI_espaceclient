-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 25 juil. 2017 à 13:25
-- Version du serveur :  5.6.17-log
-- Version de PHP :  7.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `cakefiles`
--

-- --------------------------------------------------------

--
-- Structure de la table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `filename` varchar(255) NOT NULL,
  `filedossier` varchar(255) NOT NULL,
  `tarif_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `files`
--

INSERT INTO `files` (`id`, `name`, `created`, `modified`, `filename`, `filedossier`, `tarif_id`) VALUES
(11, 'Fichier SCI', '2017-07-25 13:00:28', '2017-07-25 13:01:04', '1500987628-abf4bf543625592c2c5d737c77d1cac5.jpg', '597740ec3995b', 0),
(12, 'Fichier SCI1', '2017-07-25 13:00:48', '2017-07-25 13:01:13', '1500987648-Affiche_Concert_Pierre_Octobre_à_Lillebonne.jpg', '59774100961d3', 1),
(13, 'Fichier SCI2', '2017-07-25 13:01:40', '2017-07-25 13:01:40', '1500987700-Chrysanthemum.jpg', '59774134e3433', 2),
(14, 'Fichier SCI3', '2017-07-25 13:01:56', '2017-07-25 13:01:56', '1500987716-Desert.jpg', '597741446f8a3', 3),
(15, 'Fichier SCI4', '2017-07-25 13:02:08', '2017-07-25 13:02:08', '1500987728-Jellyfish.jpg', '5977415072f53', 4),
(16, 'Fichier SCI5', '2017-07-25 13:02:21', '2017-07-25 13:02:21', '1500987741-Lighthouse.jpg', '5977415d8bdc3', 5);

-- --------------------------------------------------------

--
-- Structure de la table `tarifs`
--

CREATE TABLE `tarifs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tarifs`
--

INSERT INTO `tarifs` (`id`, `name`, `created`, `modified`) VALUES
(0, 'SCI', '2017-07-25 00:00:00', '2017-07-25 00:00:00'),
(1, 'SCI1', '2017-07-25 00:00:00', '2017-07-25 00:00:00'),
(2, 'SCI2', '2017-07-25 00:00:00', '2017-07-25 00:00:00'),
(3, 'SCI3', '2017-07-25 00:00:00', '2017-07-25 00:00:00'),
(4, 'SCI4', '2017-07-25 00:00:00', '2017-07-25 00:00:00'),
(5, 'SCI5', '2017-07-25 00:00:00', '2017-07-25 00:00:00'),
(100, 'Pas de tarif', '2017-07-25 00:00:00', '2017-07-25 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `role` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `tarif_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created`, `modified`, `role`, `email`, `company`, `tarif_id`) VALUES
(2, 'guibrid', '$2y$10$CO60ZzoJR2kpt.5.z1rEve9pTepXiASNfTJxmpa23oS/oAdsuxsQK', '2017-07-25 00:00:00', '2017-07-25 11:36:23', 'Admin', 'support@sc-international.fr', 'SC International', 100),
(3, 'agrandedistribution', '$2y$10$73s1QnGOvrldVU6VIc1OxOdVFKCJ8DKjea/Q30uIpcQOUZxEqkZIC', '2017-07-25 12:23:48', '2017-07-25 12:23:48', 'Client', 'ad.salloub@sial.ccom', 'Alliance Grande Distribution', 0),
(4, 'detchevery', '$2y$10$H9xDWHF00UDkpt3hP/H2TuNIuXg236w6FUocvdMxRuEEIuoQd/Fra', '2017-07-25 12:26:29', '2017-07-25 12:26:29', 'Client', 'marinadetch@gmail.com', 'Detchevery', 4),
(5, 'discountcenter', '$2y$10$CywseeAoXfu9VZT2ugrSg.IMuYLgvacuqKS1tM0rn89O6qgTFvnBy', '2017-07-25 12:28:38', '2017-07-25 12:28:38', 'Client', 'discountcenter@lagoon.nc', 'Discount Center', 1),
(6, 'geantniger', '$2y$10$bZjisHL0z7hP7qyIH5aP5.Pfoa7v1xHcA6j2GFRZTOjXMYjl10nIG', '2017-07-25 12:30:08', '2017-07-25 12:30:08', 'Client', 'geantniger@hotmail.com', 'Géant Niger', 2),
(7, 'groupeazar', '$2y$10$d5fchxY5Ai8MFmWb2D822eyrUKkDDHY6v.6i0mJDjWTO0gak2tiFm', '2017-07-25 12:32:00', '2017-07-25 12:32:00', 'Client', 'gedacaaz@hotmail.com', 'Groupe Azar', 0),
(8, 'gtcmali', '$2y$10$Zv/HOPs2NPlFm3R2Xv5sOOIlNmz5BL//IWRTwEILPSa0ypAz7LpOS', '2017-07-25 12:34:09', '2017-07-25 12:34:09', 'Client', 'gtc@afribonemali.net', 'GTC Mali', 2),
(9, 'homemarket', '$2y$10$rqE5Shhk9OTQzH9rGGn7b.tkbMh7CKS7F6V5i7x5YPZ3xD4AZNXpe', '2017-07-25 12:35:21', '2017-07-25 12:35:21', 'Client', 'elie.hm@hotmail.com', 'Home Market', 0),
(10, 'jabermondial', '$2y$10$AWD3e/rWZX0jixSWQlerJeeCdR5mFY9w6LufIx3IKc/o0rrkxps9G', '2017-07-25 12:36:47', '2017-07-25 12:36:47', 'Client', 'jaber13@hotmail.com', 'Jaber Mondial', 2),
(11, 'epiceriedulevant', '$2y$10$5g5ibPbGzOkl5HyjZTlslO5YAOvO8jnZgaWmVU7mI.XshFQypkMM6', '2017-07-25 12:38:36', '2017-07-25 12:38:36', 'Client', 'bernard.kastler@epiceriedulevant.com', 'L\'épicerie du levant', 1),
(12, 'nioumart', '$2y$10$t6sZBU.noPPJZiy0zh5IC./dycLx0Dg1J6NUhY.37f0kd6UJW9FDq', '2017-07-25 12:41:10', '2017-07-25 12:41:10', 'Client', 'rayon.dor@hotmail.fr', 'Nioumart', 1),
(13, 'sial', '$2y$10$GRPATUv5wEtJ/vK9TjqSBuVe0SRxDE32XCVwZ.QzAmunc9vBCtCWq', '2017-07-25 12:45:20', '2017-07-25 12:45:20', 'Client', 'ad.salloub@sial.com', 'SIAL', 0),
(14, 'sna', '$2y$10$QYhV2WYa58rVMjKjgNtlsumgic6QJ8n29PTovbDmrAbCrtLOSLfk2', '2017-07-25 12:46:05', '2017-07-25 12:46:05', 'Client', 'contact@partnersexport.com', 'SNA', 1),
(15, 'socopramac', '$2y$10$BTxo9O8vr23xD/sOI5oFJeBkoS85KiFQwzGmrkZV0QvZUNxsLGRkC', '2017-07-25 12:47:27', '2017-07-25 12:47:27', 'Client', 'fangue00@yahoo.fr', 'Socopramac', 1),
(16, 'montssinai', '$2y$10$dcghruG9Dn46zcrhygkAbORcPuQelxjA6g9vBV.k6BzLJahAJ0VQW', '2017-07-25 12:49:00', '2017-07-25 12:49:00', 'Client', 'gpartenaire@yahoo.fr', 'Monts Sinai', 2),
(17, 'spartik', '$2y$10$Rjayejbc9bEsA7a2PgEdburDO8HTInBweHx78iJxIMxGZKwzj2Z5m', '2017-07-25 12:50:26', '2017-07-25 12:50:26', 'Client', 'douniya_gueye@yahoo.fr', 'Spartik', 3),
(18, 'superettehaamene', '$2y$10$qIHsQGbMzG60sDzfIdZESORhx0j6INvG0bQtKJkFgCjAFLkSAz8Bi', '2017-07-25 12:52:27', '2017-07-25 12:52:27', 'Client', 'aelbattah@gmail.com', 'Superette Haamene', 2),
(19, 'supremecongo', '$2y$10$kfBpDr/Ur5pmJkOVz5HEdei7f3W1VxQGZ736qEkPQztIevcYV9sDi', '2017-07-25 12:55:33', '2017-07-25 12:55:33', 'Client', 'etsupreme@hotmail.com', 'Suprême Congo', 5),
(20, 'tahitiglace', '$2y$10$sjRkoCV5nALCEb6JOBnrw.Wl4ASV9Jqyi6n3uUEgoSssyJAbnjHt6', '2017-07-25 12:57:17', '2017-07-25 12:57:17', 'Client', 'c.ly-tham@mail.pf', 'Tahiti Glace', 2);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tarif_id` (`tarif_id`);

--
-- Index pour la table `tarifs`
--
ALTER TABLE `tarifs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tarif_id` (`tarif_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `tarifs`
--
ALTER TABLE `tarifs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_ibfk_1` FOREIGN KEY (`tarif_id`) REFERENCES `tarifs` (`id`);

--
-- Contraintes pour la table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`tarif_id`) REFERENCES `tarifs` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
